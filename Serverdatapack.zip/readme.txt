Hidetag

Hide Nametags / Nameplate / Playertag / Nickname / Displayname.

This datapack hides player nametags by putting affected players into the team:
  no_display_tag (nametagVisibility = never)

IMPORTANT NOTE:
- The pack only affects players who are NOT already on another scoreboard team
  (because Minecraft only lets a player be in one team at a time).
  Players already in another team are left untouched.


-------------------------
MODES (mutually exclusive)
-------------------------

0) OFF (default)
   /function hidetag:stop

1) Normal mode (always hidden)
   /function hidetag:mode/normal
   (Backwards-compatible command: /function hidetag:start)

2) Time mode (hidden only during DAY or only during NIGHT)
   /function hidetag:mode/time/day
   /function hidetag:mode/time/night

   Day is treated as time 0–12000, Night as 12001–23999.

3) Dimension mode (hidden only in certain dimensions; pick 1 or 2)
   /function hidetag:mode/dimension/overworld
   /function hidetag:mode/dimension/nether
   /function hidetag:mode/dimension/end

   Two-dimension presets:
   /function hidetag:mode/dimension/overworld_nether
   /function hidetag:mode/dimension/overworld_end
   /function hidetag:mode/dimension/nether_end


-------------------------
INDIVIDUAL OVERRIDES
-------------------------
These override whatever server mode is active, by placing the player on a dedicated team
(so the main tick logic won't touch them).

Force-hide a single player's nametag:
  /execute as Steve run function hidetag:disable_individual

Force-show a single player's nametag:
  /execute as Alex run function hidetag:enable_individual

Reset a player back to server-default behavior:
  /execute as Notch run function hidetag:reset_individual


-------------------------
MISC
-------------------------
Show the current mode:
/function hidetag:status

Remove datapack artefacts:
/function hidetag:unload_datapack


By norkwurz
