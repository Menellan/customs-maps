# hidetag:reset_individual
# Reset *this* player back to server-default behavior (no individual override).
# Usage:
#   /execute as <player> run function hidetag:reset_individual

execute if entity @s[team=hiddenTags] run team leave @s
execute if entity @s[team=visibleTags] run team leave @s

# Optional: immediately drop out of the server-managed team too.
# The tick functions will re-assign on the next tick if the active mode requires it.
execute if entity @s[team=no_display_tag] run team leave @s

scoreboard players set @s individualTag 0
tellraw @p [{"text":"[HideTag] Returned to server default nametag visibility.","color":"blue"}]
