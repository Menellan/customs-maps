# hidetag:stop
# Disable everything and restore vanilla-visible nametags (for players controlled by this pack)

scoreboard players set #mode hidetag 0
scoreboard players set #time hidetag 0
scoreboard players set #dim hidetag 0
scoreboard players set #slow hidetag 0
data remove storage hidetag:config args

# Make sure the team is not hiding nametags and remove players from it
team modify no_display_tag nametagVisibility always
execute as @a[team=no_display_tag] run team leave @s

tellraw @p [{"text":"[HideTag] Disabled. Nametags are visible again.","color":"green"}]
