# hidetag:unload_datapack
# Removes HideTag datapack artifacts (teams, objectives, storage) from BOTH new and legacy versions.
# Run this BEFORE deleting the datapack from the datapacks folder.
#
# Usage:
#   /function hidetag:unload_datapack
#
# Notes:
# - This function attempts to remove artifacts from older pack versions too (e.g. 1.21 legacy).
# - After running, delete the datapack and run /reload.

# Stop any legacy scheduled tick loop (older versions used schedule)
schedule clear hidetag:on_tick

# Legacy join advancement cleanup (safe if it doesn't exist / isn't granted)
advancement revoke @a only hidetag:player_join

# Make sure players are not stuck in any HideTag teams (selectors are safe even if team doesn't exist)
execute as @a[team=no_display_tag] run team leave @s
execute as @a[team=hiddenTags] run team leave @s
execute as @a[team=visibleTags] run team leave @s
execute as @a[team=no_display_tag_running] run team leave @s

# Remove teams created by this datapack (new + legacy)
team remove hiddenTags
team remove visibleTags
team remove no_display_tag
team remove no_display_tag_running

# Remove objectives created by this datapack (new + legacy)
scoreboard objectives remove hidetag
scoreboard objectives remove teamInit
scoreboard objectives remove individualTag

# Old / experimental objectives that may exist from very early versions
scoreboard objectives remove sovereignTag
scoreboard objectives remove sovereignValue

# Remove command storage
data remove storage hidetag:config args

tellraw @p [{"text":"[HideTag] Datapack artifacts removed. You can now delete the datapack and run /reload.","color":"yellow"}]
