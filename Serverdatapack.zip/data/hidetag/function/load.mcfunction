# hidetag:load
# Runs on /reload and world load

# Ensure objective exists (this may print an "already exists" warning on reload; harmless)
scoreboard objectives add hidetag dummy
scoreboard objectives add individualTag dummy

# Ensure teams exist
team add no_display_tag
team add hiddenTags
team add visibleTags

# Initialize defaults only once (don’t overwrite existing settings)
execute unless score #init hidetag matches 1 run function hidetag:load/init
