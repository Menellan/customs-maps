# hidetag:start
# Backwards compatible: same as normal mode (always hide)

function hidetag:mode/normal
