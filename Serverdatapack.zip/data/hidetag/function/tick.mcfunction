# hidetag:tick
# Runs every tick (minecraft:tick tag). Does nothing when disabled.
# All modes are evaluated once every 20 ticks.

# Advance timer when enabled (mode != 0)
execute if score #mode hidetag matches 1.. run scoreboard players add #slow hidetag 1
execute unless score #mode hidetag matches 1.. run scoreboard players set #slow hidetag 0

# Run checks once per second
execute if score #mode hidetag matches 1 if score #slow hidetag matches 20 run function hidetag:tick/normal
execute if score #mode hidetag matches 2 if score #slow hidetag matches 20 run function hidetag:tick/time
execute if score #mode hidetag matches 3 if score #slow hidetag matches 20 run function hidetag:tick/dimension

# Reset timer after firing
execute if score #slow hidetag matches 20.. run scoreboard players set #slow hidetag 0

