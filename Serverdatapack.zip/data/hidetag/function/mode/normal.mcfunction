# hidetag:mode/normal
# Always hide nametags

scoreboard players set #mode hidetag 1
scoreboard players set #time hidetag 0
scoreboard players set #dim hidetag 0
data remove storage hidetag:config args

team add no_display_tag
team modify no_display_tag nametagVisibility never

tellraw @p [{"text":"[HideTag] Normal mode enabled: nametags hidden (always).","color":"aqua"}]
