# hidetag:mode/time/night
# Hide nametags only during NIGHT

scoreboard players set #mode hidetag 2
scoreboard players set #time hidetag 2
scoreboard players set #dim hidetag 0
data remove storage hidetag:config args

team add no_display_tag
team modify no_display_tag nametagVisibility never

tellraw @p [{"text":"[HideTag] Time mode enabled: nametags hidden during NIGHT only.","color":"aqua"}]
