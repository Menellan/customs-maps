# hidetag:mode/dimension/overworld_end
# Hide nametags only in: Overworld + End

scoreboard players set #mode hidetag 3
scoreboard players set #time hidetag 0
scoreboard players set #dim hidetag 5
data remove storage hidetag:config args

team add no_display_tag
team modify no_display_tag nametagVisibility never

# Apply immediately (then the slow tick keeps it updated)
function hidetag:tick/dimension

tellraw @p [{"text":"[HideTag] Dimension mode enabled: nametags hidden in Overworld + End.","color":"aqua"}]
