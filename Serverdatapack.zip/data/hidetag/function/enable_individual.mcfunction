# hidetag:enable_individual
# Force-show *this* player's nametag (individual override).
# Usage:
#   /execute as <player> run function hidetag:enable_individual
#
# Notes:
# - This overrides whatever server mode is active.

# Add the player to a team with visible nametags
team modify visibleTags nametagVisibility always
team join visibleTags @s

# Set the player's individual tag to visible
scoreboard players set @s individualTag 1
tellraw @p [{"text":"[HideTag] Player now has a visible name (individual override).","color":"dark_green"}]