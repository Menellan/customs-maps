# hidetag:disable_individual
# Force-hide *this* player's nametag (individual override).
# Usage:
#   /execute as <player> run function hidetag:disable_individual
#
# Notes:
# - This overrides whatever server mode is active.

# Add the player to a team with hidden nametags
team modify hiddenTags nametagVisibility never
team join hiddenTags @s

# Set the player's individual tag to invisible
scoreboard players set @s individualTag 2
tellraw @p [{"text":"[HideTag] Player now has an invisible name (individual override).","color":"green"}]
