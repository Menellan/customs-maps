# hidetag:status
tellraw @p [{"text":"[HideTag] mode=","color":"gray"},{"score":{"name":"#mode","objective":"hidetag"},"color":"white"},{"text":" 0=off,1=normal,2=time,3=dimension","color":"gray"}]
tellraw @p [{"text":"[HideTag] time=","color":"gray"},{"score":{"name":"#time","objective":"hidetag"},"color":"white"},{"text":" 1=day,2=night","color":"gray"}]
tellraw @p [{"text":"[HideTag] dim=","color":"gray"},{"score":{"name":"#dim","objective":"hidetag"},"color":"white"},{"text":" 1=ow,2=nether,3=end,4=ow+nether,5=ow+end,6=nether+end","color":"gray"}]
