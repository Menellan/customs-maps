# hidetag:tick/normal
# Always hide - only affects players who are not already on another team

execute as @a[team=] run team join no_display_tag @s
