# hidetag:tick/dimension
# Branch to selected dimension set (#dim = mode index)

execute if score #dim hidetag matches 1 run function hidetag:tick/dimension/overworld
execute if score #dim hidetag matches 2 run function hidetag:tick/dimension/nether
execute if score #dim hidetag matches 3 run function hidetag:tick/dimension/end
execute if score #dim hidetag matches 4 run function hidetag:tick/dimension/overworld_nether
execute if score #dim hidetag matches 5 run function hidetag:tick/dimension/overworld_end
execute if score #dim hidetag matches 6 run function hidetag:tick/dimension/nether_end
