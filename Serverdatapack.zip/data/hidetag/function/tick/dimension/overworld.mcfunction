# Hide only in overworld
execute as @a[team=no_display_tag] at @s unless dimension minecraft:overworld run team leave @s
execute as @a[team=] at @s if dimension minecraft:overworld run team join no_display_tag @s
