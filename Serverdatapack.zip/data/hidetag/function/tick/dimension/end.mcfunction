# Hide only in end
execute as @a[team=no_display_tag] at @s unless dimension minecraft:the_end run team leave @s
execute as @a[team=] at @s if dimension minecraft:the_end run team join no_display_tag @s
