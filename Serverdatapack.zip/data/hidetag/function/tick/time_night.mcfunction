# hidetag:tick/time_night
# Hide during night only, but only in overworld

# Remove from team if not in overworld
execute as @a[team=no_display_tag] at @s unless dimension minecraft:overworld run team leave @s
# Remove from team if in overworld but not night
execute as @a[team=no_display_tag] at @s if dimension minecraft:overworld unless predicate hidetag:is_night run team leave @s
# Add to team if in overworld and it's night
execute as @a[team=] at @s if dimension minecraft:overworld if predicate hidetag:is_night run team join no_display_tag @s
