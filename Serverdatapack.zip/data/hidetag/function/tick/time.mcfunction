# hidetag:tick/time
# Branches to day/night sub-modes

execute if score #time hidetag matches 1 run function hidetag:tick/time_day
execute if score #time hidetag matches 2 run function hidetag:tick/time_night
