# Only runs the first time the world loads with this datapack installed

scoreboard players set #mode hidetag 0
scoreboard players set #time hidetag 0
scoreboard players set #dim hidetag 0
scoreboard players set #slow hidetag 0

# mark initialized
scoreboard players set #init hidetag 1

# correct options
team modify no_display_tag nametagVisibility always
team modify hiddenTags nametagVisibility never
team modify visibleTags nametagVisibility always
